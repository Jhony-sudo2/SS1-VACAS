from __future__ import annotations
from sqlalchemy import Column, ForeignKey
from sqlalchemy import BigInteger, Boolean, DateTime, Integer, String
from app.db.session import Base


class Usuarios(Base):
    __tablename__ = "usuarios"

    a2f = Column(Boolean, nullable=False)
    email_verificado = Column(Boolean, nullable=False)
    estado = Column(Boolean, nullable=False)
    rol = Column(Integer, nullable=False)
    codigo_verificacion_expira = Column(DateTime)
    id = Column(BigInteger, primary_key=True, autoincrement=True, nullable=False)
    codigo_verificacion = Column(String(255))
    email = Column(String(255), nullable=False)
    password = Column(String(255), nullable=False)
