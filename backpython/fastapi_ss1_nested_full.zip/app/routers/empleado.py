from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import Field
from sqlalchemy.orm import Session, joinedload

from app.db.session import get_db
from app.models.empleados import Empleados
from app.models.horarios import Horarios
from app.models.descansos import Descansos
from app.models.areas import Areas
from app.models.asignacionarea import Asignacionarea
from app.schemas.common import CamelModel
from app.schemas.generated import AreasSchema, DescansosSchema, EmpleadosSchema, HorariosSchema

router = APIRouter(prefix="/empleado", tags=["empleado"])


class UpdateSalario(CamelModel):
    id: int
    salario: float
    bono: float
    aplica_igss: bool = Field(..., alias="aplicaIgss")


class AsignacionHorarioDTO(CamelModel):
    empleado_id: int = Field(..., alias="empleadoId")
    horario: HorariosSchema
    descansos: List[DescansosSchema]


@router.put("/salario")
def update_salario(payload: UpdateSalario, db: Session = Depends(get_db)):
    e = db.query(Empleados).filter(Empleados.id == payload.id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    if payload.salario < 0:
        raise HTTPException(status_code=404, detail="El salario no puede ser negativo")
    e.sueldo = payload.salario
    e.bono = payload.bono
    e.aplica_igss = payload.aplica_igss
    db.commit()
    return {"ok": True}


@router.get("", response_model=List[EmpleadoOut])
def all_empleados(db: Session = Depends(get_db)):
    return db.query(Empleados).order_by(Empleados.id.asc()).all()


@router.get("/id", response_model=EmpleadoOut)
def empleado_by_id(id: int = Query(...), db: Session = Depends(get_db)):
    e = db.query(Empleados).filter(Empleados.id == id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    return e


@router.post("/horario")
def asignar_horario(payload: List[AsignacionHorarioDTO], db: Session = Depends(get_db)):
    for item in payload:
        emp = db.query(Empleados).filter(Empleados.id == item.empleado_id).first()
        if not emp:
            raise HTTPException(status_code=404, detail="Empleado no encontrado")

        h_in = item.horario
        h_in.trabaja = True

        existe = db.query(Horarios).filter(Horarios.empleado_id == item.empleado_id, Horarios.dia == h_in.dia).first()
        if not existe:
            h = Horarios(
                empleado_id=item.empleado_id,
                dia=h_in.dia,
                hora_entrada=h_in.hora_entrada,
                hora_salida=h_in.hora_salida,
                trabaja=True,
            )
            db.add(h)
            db.flush()
        else:
            existe.hora_entrada = h_in.hora_entrada
            existe.hora_salida = h_in.hora_salida
            existe.trabaja = True
            h = existe
            db.flush()

        # borrar descansos existentes
        db.query(Descansos).filter(Descansos.horario_id == h.id).delete()

        for d in item.descansos:
            db.add(Descansos(horario_id=int(h.id), inicio=d.inicio, fin=d.fin))

    db.commit()
    return {"ok": True}


@router.get("/horario", response_model=List[AsignacionHorarioDTO])
def horarios_by_empleado(id: int = Query(...), db: Session = Depends(get_db)):
    emp = db.query(Empleados).filter(Empleados.id == id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")

    horarios = db.query(Horarios).filter(Horarios.empleado_id == id).order_by(Horarios.dia.asc()).all()
    out: List[AsignacionHorarioDTO] = []
    for h in horarios:
        descansos = db.query(Descansos).filter(Descansos.horario_id == h.id).order_by(Descansos.id.asc()).all()
        out.append(AsignacionHorarioDTO(empleadoId=int(emp.id), horario=h, descansos=descansos))
    return out


@router.post("/area/asignar")
def asignar_area(idEmpleado: int = Query(...), areas: List[int] = None, db: Session = Depends(get_db)):
    # Spring recibe Long[] en body. En FastAPI, accept JSON list.
    emp = db.query(Empleados).filter(Empleados.id == idEmpleado).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    if areas is None:
        raise HTTPException(status_code=400, detail="Debe enviar lista de areas")
    for area_id in areas:
        area = db.query(Areas).filter(Areas.id == area_id).first()
        if not area:
            raise HTTPException(status_code=404, detail="Area no encontrada")
        existe = db.query(Asignacionarea).filter(Asignacionarea.empleado_id == idEmpleado, Asignacionarea.area_id == area_id).first()
        if not existe:
            db.add(Asignacionarea(empleado_id=idEmpleado, area_id=area_id))
    db.commit()
    return {"ok": True}


@router.get("/areas", response_model=List[AreasSchema])
def areas_by_empleado(id: int = Query(...), db: Session = Depends(get_db)):
    emp = db.query(Empleados).filter(Empleados.id == id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    area_ids = [int(r.area_id) for r in db.query(Asignacionarea).filter(Asignacionarea.empleado_id == id).all()]
    if not area_ids:
        return []
    return db.query(Areas).filter(Areas.id.in_(area_ids)).all()
