from __future__ import annotations
from pydantic import BaseModel, EmailStr
from datetime import date
from app.schemas.auth import Rol, rol_from_ordinal, rol_to_ordinal

class UsuarioBase(BaseModel):
    email: EmailStr
    rol: Rol | int

class UsuarioCreate(UsuarioBase):
    password: str
    a2f: bool = False
    estado: bool = True
    email_verificado: bool = False

class UsuarioOut(BaseModel):
    id: int
    email: EmailStr
    rol: Rol | None
    estado: bool
    a2f: bool
    email_verificado: bool

class PacienteDTO(BaseModel):
    nombre: str
    fechaNacimiento: date | None = None
    genero: bool
    estadoCivil: bool
    telefono: str | None = None
    direccion: str | None = None

class EmpleadoDTO(BaseModel):
    nombre: str
    fechaNacimiento: date | None = None
    genero: bool
    estadoCivil: bool
    telefono: str | None = None
    colegiado: str | None = None

