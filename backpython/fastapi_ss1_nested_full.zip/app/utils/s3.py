from __future__ import annotations

import base64
import os
import uuid
from typing import Optional

try:
    import boto3  # type: ignore
except Exception:
    boto3 = None


def upload_base64_to_s3(data_b64: Optional[str], key_prefix: str = "upload") -> Optional[str]:
    """Compat con tu Spring S3Service.uploadBase64.

    - Si no hay credenciales/env, devuelve el mismo string (para no romper).
    - Si data_b64 ya parece URL (http/https), lo devuelve igual.
    - Si data_b64 es None/vacío, devuelve None.
    """
    if not data_b64:
        return None
    if isinstance(data_b64, str) and (data_b64.startswith("http://") or data_b64.startswith("https://")):
        return data_b64

    bucket = os.getenv("AWS_S3_BUCKET_NAME") or os.getenv("aws_s3_bucket_name")
    region = os.getenv("AWS_S3_REGION") or os.getenv("aws_s3_region")
    access_key = os.getenv("AWS_S3_ACCESS_KEY") or os.getenv("aws_s3_access_key")
    secret_key = os.getenv("AWS_S3_SECRET_KEY") or os.getenv("aws_s3_secret_key")

    if not (bucket and region and access_key and secret_key and boto3):
        # modo local/dev: no intentamos subir
        return data_b64

    # limpiar prefix data URI
    raw = data_b64
    if "," in raw and raw.strip().lower().startswith("data:"):
        raw = raw.split(",", 1)[1]
    try:
        payload = base64.b64decode(raw)
    except Exception:
        # si no decodifica, devolvemos tal cual
        return data_b64

    s3 = boto3.client(
        "s3",
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
    )

    key = f"{key_prefix}/{uuid.uuid4().hex}.bin"
    s3.put_object(Bucket=bucket, Key=key, Body=payload)
    return f"https://{bucket}.s3.{region}.amazonaws.com/{key}"
